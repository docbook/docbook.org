# The DocBook Schemas

[![Build Status](https://travis-ci.org/docbook/docbook.svg?branch=master)](https://travis-ci.org/docbook/docbook.svg?branch=master)

This repository contains the sources for the DocBook schemas. All of
the revision history from the Sourceforge days has been preserved.
